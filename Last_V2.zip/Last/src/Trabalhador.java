import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;


public class Trabalhador extends Thread {
	
	private Socket t;
	
	public Trabalhador( Socket t )
	{
		this.t = t;
	}
	
	public void run()
	{
		try
		{

			DataInputStream entrada = new DataInputStream( t.getInputStream());
			DataOutputStream saida = new DataOutputStream( t.getOutputStream());
			
			String dados = entrada.readUTF();
			String array[] = new String[3];
			array = dados.split("/");

			System.out.println( "Recebidos: " + array[0] + ", " + array[1] + " e " + array[2] );
			
			Thread.sleep( 5000 ); // dorme 5 segundos
			
			//double produto = k * f;
			//float produto = k * f;
			//System.out.println( "produto = " + produto );
			saida.writeUTF( array[2] );
			//saida.writeFloat( produto );
			
			t.close();
			System.out.println( "Servidor: conexao encerrada");
		}
		catch( Exception e )
		{
			System.out.println( e );
		}
		
	}

}

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;


public class Trabalhador extends Thread {
	
	private Socket t;
	private String[] users;
	private Pilha[] mensagens;
	
	public Trabalhador( Socket t, Pilha[] p, String[] users)
	{
		this.t = t;
		this.mensagens  = p;
		this.users = users;
	}
	
	public void run()
	{
		try
		{

			DataInputStream entrada = new DataInputStream( t.getInputStream());
			DataOutputStream saida = new DataOutputStream( t.getOutputStream());


			int id = entrada.readInt();
			//System.out.println(id);
			String men = "";
			if(mensagens[id].vazia() == false){
				System.out.println("essa sao suas mensagens:");
				for(int i = 0; i < mensagens[id].getPilha().size(); i++){
					men = men + mensagens[id].getPilha().get(i) + "\n";
				}
				mensagens[id].clear();
			}else{
				men = "Voce nao tem mensagens";
			}
			saida.writeUTF(men);

			String dados = entrada.readUTF();
			String array[] = new String[3];
			array = dados.split("/");
			//System.out.println(dados);
			mensagens[Integer.parseInt(array[1])].empilha("Mensagem de :" + users[Integer.parseInt(array[0])] + " / " + "Mensagem: " + array[2]);

			Thread.sleep( 5000 ); // dorme 5 segundos


			saida.writeUTF("mensagem enviada!");
			t.close();
			System.out.println( "Servidor: conexao encerrada");
		}
		catch( Exception e )
		{
			System.out.println( e );
		}
		
	}

}
